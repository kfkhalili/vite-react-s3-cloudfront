const { CognitoIdentityServiceProvider } = require('aws-sdk');
const cognito = new CognitoIdentityServiceProvider();

export async function handler(event) {
    try {
        const { email, password } = event.arguments;

        const loginResponse = await cognito.initiateAuth({
            AuthFlow: 'USER_PASSWORD_AUTH',
            ClientId: process.env.COGNITO_CLIENT_ID, // Set in Lambda environment variables
            AuthParameters: {
                USERNAME: email,
                PASSWORD: password
            }
        }).promise();

        return {
            success: true,
            message: "Login successful",
            token: loginResponse.AuthenticationResult.IdToken
        };
    } catch (error) {
        console.error(error);
        return {
            success: false,
            message: error.message
        };
    }
}
