const { CognitoIdentityServiceProvider } = require('aws-sdk');
const cognito = new CognitoIdentityServiceProvider();

export async function handler(event) {
    try {
        const { email, password } = event.arguments;

        const signUpResponse = await cognito.signUp({
            ClientId: process.env.COGNITO_CLIENT_ID, // Set in Lambda environment variables
            Username: email,
            Password: password,
            UserAttributes: [
                {
                    Name: 'email',
                    Value: email
                }
            ]
        }).promise();

        return {
            success: true,
            message: "User registered successfully",
            user: {
                id: signUpResponse.UserSub,
                email: email
            }
        };
    } catch (error) {
        console.error(error);
        return {
            success: false,
            message: error.message
        };
    }
}
